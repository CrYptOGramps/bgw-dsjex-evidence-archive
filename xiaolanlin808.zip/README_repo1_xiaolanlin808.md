# Evidence: XiaolanLin808/BG-Wealth_SCript

## File: app_cpython-312.pyc

| Field | Value |
|---|---|
| **Filename** | app_cpython-312.pyc |
| **Type** | Byte-compiled Python module (CPython 3.12) |
| **MD5 hash** | 4d79a47c4f78bcd1714583c844394d29 |
| **Original .py size** | 19,073 bytes |
| **Original .py last modified** | Saturday, April 4, 2026 01:19:34 UTC |
| **Source repository** | github.com/XiaolanLin808/BG-Wealth_SCript |
| **Repository status** | DELETED — taken down after public reporting |
| **Captured by** | Agent 00bob / Agent 001 (Danny de Hek Avengers community) |

---

## What This File Is

This is the compiled Python backend for the DSJ Exchange automation system, internally named **"DSJ Token System"**. It was extracted from the now-deleted GitHub repository `XiaolanLin808/BG-Wealth_SCript` before it was removed.

The repository contained a commercial Flask web application that automated the submission of trading signal codes into BG Wealth Sharing / DSJ Exchange accounts on behalf of paying operators.

---

## What the Code Proves

The backend confirms that the "AI trading" system promoted by BG Wealth Sharing is a fully automated form submission tool — not artificial intelligence, not human analysis, not genuine market trading.

**Key findings from decompilation:**

### 1. Credential harvesting
The system stored real victim DSJ Exchange credentials — phone numbers, passwords, full names, country codes — in a central SQL database accessible via an admin panel.

### 2. Pay-per-run token economy
Operators were charged one token per automated trade submission via the `/api/deduct` endpoint. HTTP 402 (Payment Required) was returned when tokens were exhausted. Stripe payment integration was included.

### 3. Two automation scripts
- `automate_login.py` — automated login to DSJ Exchange accounts
- `automated_entry.py` — automated signal code submission

### 4. Production deployment
The system was deployed on Railway.app (live cloud hosting), not a local development environment. The deployment guide is included in the repository README.

### 5. Default admin credentials never changed
The code hardcodes the default admin account as:
- Username: `admin`
- Password: `admin123`

The console output on first run states: *"Admin created: username=admin password=admin123 — CHANGE THIS!"* — indicating the developer anticipated these would need to be changed. Evidence suggests they were not.

### 6. Victim credentials exposed
With default admin credentials left unchanged, the admin panel at `https://[deployment-url]/admin` was accessible to anyone who found the URL, exposing all stored victim phone numbers and passwords.

### 7. Real phone number in deployment guide
The README documentation for the `/api/deduct` API endpoint contains a real US phone number (808 area code — Hawaii) used as a worked example — almost certainly the developer's own DSJ Exchange test account.

### 8. Active maintenance
The original app.py was last modified on **April 4, 2026** — confirming this was live, actively maintained production infrastructure, not an abandoned project.

---

## Complete Route List

```
/register
/login
/logout
/dashboard
/phones/add          — stores: phone, password, country_code, full_name
/phones/delete/<id>
/phones/toggle/<id>
/buy/<package_id>    — Stripe checkout
/buy/success
/stripe/webhook
/admin               — full credential and balance management
/admin/tokens        — manual token top-up per user
/admin/packages/add
/admin/packages/delete/<id>
/admin/user/delete/<id>
/api/accounts        — serves credentials to automation scripts
/api/deduct          — deducts 1 token per run
/admin/run           — executes automate_login.py or automated_entry.py
/admin/run/stream    — Server-Sent Events: streams script output
/admin/run/stop
/admin/run/status
```

---

## Chain of Custody

This file was uploaded to this investigation repository directly from the original .pyc file captured before the repository was deleted. The MD5 hash `4d79a47c4f78bcd1714583c844394d29` can be used to verify the file has not been altered.

---

## Related Evidence

- Agent 00bob screenshots of README deployment guide: `phone_number_in_bgw_code_on_github_snap.jpeg` (x3)
- Reconstructed app.py source: available in investigation archive
- Developer identity chain: documented separately — LAW ENFORCEMENT REFERRAL ONLY
- Law enforcement referral: submitted to IC3, Action Fraud, FCA, and Danny de Hek

---

## Regulatory Context

At the time this backend was actively maintained (April 4, 2026), the following regulatory warnings against BG Wealth Sharing / DSJ Exchange were already published:

| Regulator | Date |
|---|---|
| FCA (UK) | May 7, 2025 |
| ASIC (Australia) | 2025 |
| FMA (New Zealand) | April 25, 2025 |
| National Reserve Bank of Tonga | December 2025 |
| Central Bank of Bahamas | 2025 |
| SEC Philippines | January 28, 2026 |
| ASC (Alberta, Canada) | February 17, 2026 |
| FCAA (Saskatchewan, Canada) | March 13, 2026 |
| Utah Division of Securities | March 10, 2026 |
| Washington State DFI | April 10, 2026 |

---

*Captured as part of the CrYptOG investigation into BG Wealth Sharing / DSJ Exchange.*
*Part 1: https://youtu.be/exgrNmrqA08*
