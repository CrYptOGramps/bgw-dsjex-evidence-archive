# Evidence: Navyakushwaha/DSJ-Exchange

## File: DSJ-Exchange-main.zip

| Field | Value |
|---|---|
| **Filename** | DSJ-Exchange-main.zip |
| **Type** | React/Vite JavaScript project — complete website source |
| **MD5 hash** | 577a74126ba8e412a7aa1a1b3705de80 |
| **File count** | 42 files |
| **All file timestamps** | 2026-02-11 07:25 UTC (single commit, one day) |
| **ZIP size** | 2,944,288 bytes (~2.9MB) |
| **Source repository** | github.com/Navyakushwaha/DSJ-Exchange |
| **Repository status** | LIVE as of April 2026 |
| **Commits URL** | github.com/Navyakushwaha/DSJ-Exchange/commits?author=Navyakushwaha |

---

## What This File Is

This is the complete source code for the **DSJ Exchange website frontend** — the public-facing marketing and landing page for the BG Wealth Sharing fraud platform. It was committed to GitHub by a developer named Navya Kushwaha on February 11, 2026, while multiple regulatory authorities around the world were actively warning the public against DSJ Exchange.

This is not an affiliate tool or peripheral component. This is the DSJ Exchange website itself — the shop window that makes the operation appear to be a legitimate cryptocurrency exchange to new victims before they download the trading app.

The repository contains 42 files, all timestamped to the same day, committed by a single developer, built on a standard free Vite React template.

A fully rendered version of the website (with all images embedded) is available separately as `DSJ_Exchange_rendered.html`.

---

## File Structure

```
DSJ-Exchange-main/
├── index.html
├── package.json
├── vite.config.js
├── eslint.config.js
├── .gitignore
├── README.md                          ← original developer README (default Vite template)
├── public/
│   └── images/
│       ├── Logo.png
│       ├── about.png
│       ├── bulletes.png
│       ├── card-img1.png through card-img4.png
│       ├── header.png
│       ├── icon1.png (BTC)
│       ├── icon2.png (ETH)
│       ├── icon3.png (TRX)
│       ├── icon4.png (XRP)
│       ├── laptop.png
│       ├── mcard1.png through mcard4.png
│       └── qr.png
└── src/
    ├── App.jsx
    ├── main.jsx
    ├── index.css
    ├── App.css
    ├── assets/
    └── Components/
        ├── Common/
        │   ├── Navbar.jsx
        │   └── Footer.jsx
        └── Home/
            └── Home.jsx              ← ALL FIVE SMOKING GUNS LOCATED HERE
```

---

## Five Smoking Guns

All five smoking guns are located in `src/Components/Home/Home.jsx` and `src/Components/Common/Footer.jsx`.

---

### SMOKING GUN 1 — Fake SEC Licence Number Hardcoded

**File:** `src/Components/Home/Home.jsx`
**Location:** Ticker bar announcement at top of page

```jsx
<p>Good news: DSJX successfully applied for a SEC licence from the U.S. Securities and Exchange
    Commision on July 11, 2025. CLK:0002078856</p>
```

**Why this is a smoking gun:**
- CIK `0002078856` is not the actual DSJ Exchange filing — the real DSJ Exchange PTY Ltd CIK is `0002076856`
- Differs by two digits — BGW got their own fake number wrong
- A Form D is not a licence — it is a free notice of exempt offering that anyone can file in minutes
- The SEC explicitly states on every Form D: *"The SEC has not necessarily reviewed this filing and has not determined if it is accurate and complete"*
- Total amount raised on the actual filing: **$0**

---

### SMOKING GUN 2 — Fabricated Founding Date

**File:** `src/Components/Common/Footer.jsx`
**Location:** Footer copyright line

```jsx
<div className="...text-xs text-gray-500">
    Copyright © 2018-2026 DSJ Exchange All Rights Reserved
</div>
```

**Why this is a smoking gun:**
- DSJ Exchange Limited (UK) incorporated: July 2024
- DSJ Exchange PTY Ltd (Colorado) incorporated: June 30, 2025
- No investigator or regulator has placed the company's existence before 2022 at the earliest
- 2018 is a fabricated eight-year history designed to imply an established institution

---

### SMOKING GUN 3 — Hardcoded Frozen Price Data

**File:** `src/Components/Home/Home.jsx`
**Location:** Price ticker data array

```javascript
const data = [
    {
        name: "BTCUSDT",
        price: "69106.28",
        change: "+0.00",
        color: "bg-green-900/40",
        icon: "/images/icon1.png",
    },
    {
        name: "ETHUSDT",
        price: "2030.58",
        change: "+0.00",
        color: "bg-green-900/40",
        icon: "/images/icon2.png",
    },
    {
        name: "TRXUSDT",
        price: "0.27753",
        change: "+0.03",
        color: "bg-green-900/40",
        icon: "/images/icon3.png",
    },
    {
        name: "XRPUSDT",
        price: "1.4187",
        change: "-0.02",
        color: "bg-red-900/40",
        icon: "/images/icon4.png",
    },
];
```

**Why this is a smoking gun:**
- Static values hardcoded with no API connection to any market data feed
- BTC was not $69,106 in February 2026 — months out of date
- `+0.00` change on BTC and ETH means no one updated the static numbers before shipping
- Real exchanges pull live prices via WebSocket every millisecond
- The `+0.00` value is proof these are frozen — not even attempting to simulate live data

---

### SMOKING GUN 4 — Lorem Ipsum Placeholder in Production

**File:** `src/Components/Home/Home.jsx`
**Location:** "Trade anyTime" section

```jsx
<div className="pt-5">
    <h3 className="text-xl font-semibold">Trade anyTime, anywhare</h3>
    <p className="text-sm text-gray-500">Lorem ipsum dolor sit, amet consectetur adipisicing elit. 
    Dignissimos, eligendi recusandae alias ipsum saepe ipsam?</p>
</div>
```

**Why this is a smoking gun:**
- Lorem ipsum is standard template placeholder text — never replaced before deployment
- "anywhare" is also a typo in the heading
- Proves this is a rushed template deployment, not a professionally built exchange

---

### SMOKING GUN 5 — Machine-Translated Broken English

**File:** `src/Components/Home/Home.jsx`
**Location:** About Us section

```jsx
<div className="text-gray-400 text-sm leading-relaxed w-full lg:w-5/12">
    DSJ Exchange Global Professional Station is an innovative digital asset trading users around 
    the world, focusing on discovering and opportunities. Currently, the platform provides trading 
    and financial services and is headquartered in Australia and operated by a professional DSJ 
    Exchange team. As the world's leading blockchain asset financial service provider, DSJ Exchange 
    has provided high-quality services to millions of users from more than 130 countries and regions 
    including Singapore, covering trading business and operation service systems, and are committed 
    to providing users with a safe, convenient trading experience.
</div>
```

**Why this is a smoking gun:**
- "innovative digital asset trading users around the world" — grammatically broken, verb missing
- "focusing on discovering and opportunities" — sentence fragment, words missing
- Consistent with machine translation from Chinese
- Fingerprint of Chinese scam factory production documented by BehindMLM

---

## Additional Evidence in Source

### Hardcoded news headlines (not live content)
The website displays four "news" stories with hardcoded titles and dates. Several carry dates of 2025-12-20 — already months old when deployed in February 2026. No CMS, no API, no live content feed exists.

### Bottom section claims (hardcoded, unverified)
```
"Professional compliance — Professional operation team, blockchain experience, 
financial trading license, and deposit guarantee."
```
No such trading licence is evidenced by any regulatory registration.

---

## Regulatory Context

At the time this repository was committed (February 11, 2026), the following regulatory warnings against BG Wealth Sharing / DSJ Exchange were already published:

| Regulator | Warning Date |
|---|---|
| FCA (UK) | May 7, 2025 |
| ASIC (Australia) | 2025 |
| FMA (New Zealand) | April 25, 2025 |
| National Reserve Bank of Tonga | December 2025 |
| Central Bank of Bahamas | 2025 |
| SEC Philippines | January 28, 2026 |
| ASC (Alberta, Canada) | February 17, 2026 |

The repository was committed while at least six regulatory authorities had already formally warned the public against this platform.

---

## Chain of Custody

This ZIP was downloaded directly from the public GitHub repository `github.com/Navyakushwaha/DSJ-Exchange` before any modification. The MD5 hash `577a74126ba8e412a7aa1a1b3705de80` can be used to verify the archive has not been altered.

A fully rendered HTML version of the website (all images embedded, Lorem ipsum highlighted) is available separately as `DSJ_Exchange_rendered.html`.

---

*Captured as part of the CrYptOG investigation into BG Wealth Sharing / DSJ Exchange.*
*Part 1: https://youtu.be/exgrNmrqA08*
